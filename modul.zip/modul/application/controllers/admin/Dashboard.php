<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function index()
	{
		$data['biodata'] = $this->Model_biodata->tampil_biodata();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('admin/dashboard', $data);
		$this->load->view('templates/footer');
	}
	public function detail($id)
    {
        $data['biodata'] = $this->Model_biodata->detail($id);
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('admin/biodata', $data);
        $this->load->view('templates/footer');
    }
    public function hapus($id)
    {
        $where = array('id' => $id);
        $this->Model_biodata->hapus($where, 'biodata');
        redirect('admin/dashboard');
    }
    public function pdf()
    {
        date_default_timezone_set('Asia/Jakarta');
        $this->load->library('Dompdf_gen');
        
        $data['biodata'] = $this->Model_biodata->tampil_biodata();
        
        $this->load->view('admin/print', $data);

        $paper_size = 'A4';
        $orientation = 'portrait';
        $html = $this->output->get_output();
        $this->dompdf->set_paper($paper_size, $orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("data_pesanan.pdf", array('Attachment' =>0));
    }
}