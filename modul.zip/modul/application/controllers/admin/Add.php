<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Add extends CI_Controller {

	public function index()
	{
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('admin/add');
		$this->load->view('templates/footer');
	}
	public function tambah_biodata()
    {
        $nama = $this->input->post('nama');
        $jenis_kelamin = $this->input->post('jenis_kelamin');
        $email = $this->input->post('email');
        $telp = $this->input->post('telp');
        $tempat_lahir = $this->input->post('tempat_lahir');
        $tanggal_lahir = $this->input->post('tanggal_lahir');
        $photo_sampul = $_FILES['photo_sampul']['name'];
        if ($photo_sampul = '') {
        } else {
            $config['upload_path'] = './img';
            $config['allowed_types'] = 'jpg|jpeg|png';

            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('photo_sampul')) {
                echo 'Bukti Gagal di Upload!';
                die();
            } else {
                $photo_sampul = $this->upload->data('file_name');
            }
        }
        $data = [
            'nama' => $nama,
            'jenis_kelamin' => $jenis_kelamin,
            'email' => $email,
            'telp' => $telp,
            'tempat_lahir' => $tempat_lahir,
            'tanggal_lahir' => $tanggal_lahir,
            'photos_sampul' => $photo_sampul,
        ];

        $this->Model_biodata->tambah_biodata($data,'biodata');
        redirect('admin/dashboard');
    }
    public function print_biodata($id)
    {
        $data['biodata'] = $this->Model_biodata->detail($id);
        $this->load->view('templates/header');
        $this->load->view('admin/print_biodata', $data);
    }
}