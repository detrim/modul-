<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Beranda extends CI_Controller {

	public function index()
	{
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar2');
		$this->load->view('beranda');
		$this->load->view('templates/footer');
	}
	public function project()
	{
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar2');
		$this->load->view('project');
		$this->load->view('templates/footer');
	}
}
