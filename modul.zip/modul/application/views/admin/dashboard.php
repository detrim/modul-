


    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <a href="<?php echo base_url('admin/add') ?>" class="btn btn-sm btn-dark"><i
                        class="fas fa-plus fa-sm"></i> Tambah Data</a>
        <a onclick="javascript: return confirm('Print Data?')" class="btn btn-sm btn-danger"
        target="blank_akun" href="<?php echo base_url('admin/dashboard/pdf') ?>"><i
        class="fa fa-print"></i> Print</a>    
      </div>

      <table id="example" class="table table-sm">
        <thead>
            <tr>
              <th>No</th>
              <th>Nama</th>
              <th>Email</th>
              <th>No.Telp</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
                <?php
                $no = 1;
                  foreach ($biodata as $bi) :
                ?>
            <tr>
              <td><?php echo $no++ ?></td>
              <td><?php echo $bi->nama ?></td>
              <td><?php echo $bi->email ?></td>
              <td><?php echo $bi->telp ?></td>
              <td><?php echo anchor('admin/dashboard/detail/' .$bi->id, '<div class="btn btn-outline-success btn-sm"><i class="fa-solid fa-folder-open"></i></div>') ?>
                <?php echo anchor('admin/dashboard/hapus/' .$bi->id, '<div class="btn btn-outline-danger btn-sm"><i class="fa-solid fa-trash"></i></div>') ?>
              </td>
            </tr>
          <?php endforeach;?>
          </tbody>
      </table>
      

      
      </div>
    </main>
  </div>
</div>



