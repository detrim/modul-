    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <a href="<?php echo base_url('admin/dashboard') ?>" class="btn btn-sm btn-primary"><i class="fa-solid fa-arrow-left"></i> Kembali</a>
      </div> 
      
<table class="table table-sm">

    <div>
    <form action="<?php echo base_url(). 'admin/add/tambah_biodata'; ?>" method="post"
                        enctype="multipart/form-data">
    <h3 class="alert alert-primary text-center ">Isi Biodata Diri</h3>


        <div class="row mb-3 mt-3">
            <div class="col-md-6">
                <div class="form-group text-black">
                    <label for="namalengkap">Nama Lengkap</label>
                    <input type="text" name="nama" class="form-control" placeholder="Masukkan Nama Lengkap Anda" id="namalengkap">
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group text-black">
                    <label>Jenis Kelamin</label><br>
                    <div class="form-check-inline">
                        <input type="radio" name="jenis_kelamin" value="Laki-Laki" class="form-check-input" id="radio2" checked="">
                        <label class="text-dark">Laki-Laki</label>
                    </div>

                    <div class="form-check-inline">
                        <input type="radio" name="jenis_kelamin" value="Perempuan" class="form-check-input">
                        <label class="text-dark">Perempuan</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mb-3 mt-3">
            <div class="col-md-6">
                <div class="form-group text-black">
                    <label for="Email">Email</label>
                    <input type="email" name="email" class="form-control"  placeholder="Masukkan Email Anda" id="Email">
                </div>
            </div>



            <div class="col-md-6">
                <div class="form-group text-black">
                    <label for="Telp">No. Telp</label>
                    <input type="number" name="telp" class="form-control" placeholder="Masukkan No. Telp Anda" id="Telp">
                </div>
            </div>
        </div>

        <div class="row mb-3 mt-3">
            <div class="col-md-6">
                <div class="form-group text-black">
                    <label for="tempatlahir">Tempat Lahir</label>
                    <input type="text" name="tempat_lahir" class="form-control" placeholder="Masukkan Tempat Lahir Anda" id="tempatlahir">
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group text-black">
                    <label>Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" class="form-control">
                </div>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-12">
                <div class="form-group text-black">
                    <label for="photo">Photo Sampul</label>
                    <input type="file" name="photo_sampul" required class="form-control">
                </div>
            </div>

        </div>
        <center>
            <button type="submit" class="btn btn-primary">SIMPAN</button>
            <button type="reset" class="btn btn-danger">RESET</button>
        </center>
        

    </form>
    </div>
    </table>

      

<canvas class="my-4 w-100" id="myChart" width="900" height="0"></canvas>
      </div>
    </main>
    </div>
