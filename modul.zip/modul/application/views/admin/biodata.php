<?php foreach($biodata as $bi): ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <a onclick="javascript: return confirm('Print Biodata Diri ?')" class="btn btn-sm btn-dark" target="print_biodata_diri" href="<?php echo base_url('admin/add/print_biodata/' .$bi->id) ?>"><i class="fa fa-print"></i> Print</a>
        <a class="btn btn-sm btn-primary" href="<?php echo base_url('admin/dashboard') ?>"><i class="fa-solid fa-arrow-left"></i> Kembali</a>
      </div> 


<div class="row">
    <label class="text-center"><strong>BIODATA DIRI</strong></label> 
<div class="col-md-4">
            <img src="<?php echo base_url(). '/img/'.$bi->photos_sampul ?>" width="100%" height="400px">
            <br><br>
            </div>
       
            
<div class="col-md-8">
        <form class="forms-sample">
            <div class="form-group row">
                <label class="col-md-4 col-form-label">Nama</label>
                <label class="col-md-8 col-form-label">: <?php echo $bi->nama ?></label>
            </div>
            <div class="form-group row">
                <label class="col-md-4 col-form-label">Jenis Kelamin</label>
                <label class="col-md-8 col-form-label">: <?php echo $bi->jenis_kelamin ?></label>
            </div>
            <div class="form-group row">
                <label class="col-md-4 col-form-label">Email</label>
                <label class="col-md-8 col-form-label">: <?php echo $bi->email ?></label>
            </div>
            <div class="form-group row">
                <label class="col-md-4 col-form-label">No. Telp</label>
                <label class="col-md-8 col-form-label">: <?php echo $bi->telp ?></label>
            </div>
            <div class="form-group row">
                <label class="col-md-4 col-form-label">Tempat dan Tanggal Lahir</label>
                <label class="col-md-8 col-form-label">: <?php echo $bi->tempat_lahir ?>, <?php echo date('d-m-Y', strtotime($bi->tanggal_lahir))  ?></label>
            </div>
        </form>
        </div>
        </div>
<?php endforeach; ?>
</div>

