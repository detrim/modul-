<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title></title>

<style>
.table {
    border-collapse: collapse;
    border: 1px solid black;
    font-size: 10px;
}
.font{
    font-size: 11px;
}
.hr{
   
    border: 1px solid black; 
    border-color: black;
    margin-top: -2px;
            
}
.head{
    margin-top: -2px;
}
.turun{
    margin-top: 2px;
}
.turunn{
    margin-top: 10px;
}
.turunnn{
    margin-top: 30px;
}

.naik{
    margin-top: -96px;
}

.total{
    border-top: 5px double #8e8e8e;
}
body{
    font-size: 11px;
}

</style>
</head><body>
    <h2 class="head">COMPANY</h2>
    <span >Jl. Meruya Selatan No.31, RT.4/RW.1, Meruya Sel., Kec. Kembangan, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11610</span>
    <p class="hr"></p>
    <center>
    <h2 class="turunn">DAFTAR BIODATA DIRI</h2>
    </center>

<strong class="font"><?php echo date('d/m/Y')  ?></strong>
<table rules="cols"  align="center" border="1" class="table" width="100%">
        <head>
        <tr> 
            <th>NO</th>   
            <th>NAMA</th>
            <th>EMAIL</th>
            <th>NO. TELP</th>
        </tr>
    </head>
    <body>
       <?php
        $no = 1;
        foreach ($biodata as $bi) :?>

        <tr>
            <td align="center"><?php echo $no++ ?></td>
            <td align="center"><?php echo $bi->nama ?></td>
            <td align="center"><?php echo $bi->email ?></td>
            <td align="center"><?php echo $bi->telp ?></td>
        </tr>

        <?php endforeach;?>
        </body>
    </table>
    <br>
    
</body></html>
