
        <div class="container-fluid table-bordered card">
            <div class="row" >
            <div class="col-md-12 ">
            <br>  
                <center >
                    <div class="page-header ">
                    <div class="page-header-title">
                        <strong><h5>BIODATA DIRI</h5></strong>
                    </div>
                </div>
                </center>
    </div>
</div>

<?php foreach($biodata as $bi): ?>
<div class="row">
<div class="col-md-4">
            <img src="<?php echo base_url(). '/img/'.$bi->photos_sampul ?>" width="100%" height="400px">
            <br><br>
            </div>
       
            
<div class="col-md-8">
        <form class="forms-sample">
            <div class="form-group row">
                <label class="col-md-4 col-form-label">Nama</label>
                <label class="col-md-8 col-form-label">: <?php echo $bi->nama ?></label>
            </div>
            <div class="form-group row">
                <label class="col-md-4 col-form-label">Jenis Kelamin</label>
                <label class="col-md-8 col-form-label">: <?php echo $bi->jenis_kelamin ?></label>
            </div>
            <div class="form-group row">
                <label class="col-md-4 col-form-label">Email</label>
                <label class="col-md-8 col-form-label">: <?php echo $bi->email ?></label>
            </div>
            <div class="form-group row">
                <label class="col-md-4 col-form-label">No. Telp</label>
                <label class="col-md-8 col-form-label">: <?php echo $bi->telp ?></label>
            </div>
            <div class="form-group row">
                <label class="col-md-4 col-form-label">Tanggal Lahir</label>
                <label class="col-md-8 col-form-label">: <?php echo $bi->tanggal_lahir ?></label>
            </div>
            <div class="form-group row">
                <label class="col-md-4 col-form-label">Tempat dan Tanggal Lahir</label>
                <label class="col-md-8 col-form-label">: <?php echo $bi->tempat_lahir ?>, <?php echo date('d-m-Y', strtotime($bi->tanggal_lahir))  ?></label>
            </div>
        </form>
        </div>
        </div>
<?php endforeach; ?>
</div>
<script type="text/javascript">
    window.print();
</script>

