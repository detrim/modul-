<style>
.con{
    padding-left: 25%;
    padding-right: 25%;
}
.con form{

    padding: 10%;
    margin-top: 20%;
    box-shadow: 0 3px 20px rgba(0,0,0,0.3);
    padding-top: 20px;
    padding-bottom: 20px;
}
.co {
    padding-left: 11%;
    padding-right: 11%;
}
.co form{
    padding: 10%;
    margin-top: 8%;
    box-shadow: 0 3px 20px rgba(0,0,0,0.3);
    padding-top: 20px;
    padding-bottom: 20px;
}
</style>
<body class="bg-dark">

<div class="con">
    <form method="post" action="<?php echo base_url('auth/login') ?>">
        <h3 class="alert alert-success text-center ">Login</h3>

        <div class="form-group text-white text-center">
            <label for="username">Username</label>

            <div class="input-group mb-3 mt-3">
                <span class="input-group-text"><i class="fas fa-user"></i></span>
                <input type="text" name="username" required="" class="form-control" placeholder="Masukkan Username Anda" id="username">
        </div>
        </div>

        <div class="form-group text-white text-center">
            <label for="Password">Password</label>

            <div class="input-group mb-3 mt-3">
              <span class="input-group-text"><i class="fas fa-unlock-alt"></i></span>
              <input type="password" name="password" required="" class="form-control" placeholder="Masukkan Password Anda" id="Password">
        </div>
        </div>

        
        <div class="text-center">
            <button class="btn btn-primary">SUBMIT</button>
            <button class="btn btn-danger">RESET</button>
        </div>
        <p class="text-white">username : admin</p>
        <p class="text-white">password : 123</p>
        <a href="<?php echo base_url('beranda') ?>" class="btn btn-sm btn-dark"><i class="fa-solid fa-door-open"></i></a>
    </form>
    
    </div>


</script>