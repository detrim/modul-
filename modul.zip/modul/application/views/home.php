<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url() ?>assets/bootstrap/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>assets/bootstrap/css/bootstrap.min.css">
    <link href="<?php echo base_url() ?>assets/bootstrap/css/all.css" rel="stylesheet"> <!--load all styles -->
    <script defer src="<?php echo base_url() ?>assets/bootstrap/js/all.js"></script>
    <title>Hello, world!</title>
</head>
<body class="jumbo" >
<nav class="navbar navbar-expand-lg navbar-light bg-sendiri fixed-top" id="mainNav">
    <div class="container">
        <a class="navbar-brand font-weight-bold text-white" href="#page-top">PPSI</a>
        <button class="navbar-toggler navbar-toggler-light bg-white " type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item ml-1 mr-1">
                    <a class="nav-link js-scroll-trigger text-white " href="Copy.html">Home </a>
                </li>
                <li class="nav-item ml-1 mr-1 ">
                    <a class="nav-link js-scroll-trigger text-white" href="store.html">Daftar Barang</a>
                </li>
                <li class="nav-item mr-1 ml-1 ">
                    <a class="nav-link js-scroll-trigger text-white" href="#">Tentang Kami</a>
                </li>
                <li class="nav-item mr-1 ml-1 ">
                    <a class="nav-link js-scroll-trigger text-white" href="#contohmodal"  data-toggle="modal"  data-target="#contohmodal">Saran</a>
                </li>
                <li class="nav-item dropdown text-white">
                    <a class="nav-link dropdown-toggle-split text-white" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-user ml-1 mr-1" aria-hidden="true"></i>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right " aria-labelledby="navbarDropdown">
                        <a class="dropdown-item text-info" href="login.html">Masuk</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-success" href="register.html">Daftar</a>
                    </div>
                </li>
                <li class="nav-item dropdown text-white">
                    <a class="nav-link dropdown-toggle-split text-white" href="#" id="dropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-search ml-1 mr-1" aria-hidden="true"></i>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right " aria-labelledby="dropdownMenuLink">
                        <form action="store.html">
                            <a class="form-inline">
                                <input class="form-control mr-sm-2 ml-sm-2" type="search"  placeholder="Search" aria-label="Search">
                            </a>
                        </form>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="modal fade" id="contohmodal" role="dialog" aria-labelledby="contohmodal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Hubungi Kami</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <form>
                <div class="modal-body">

                    <div class="form-group text-left">
                        <label>Nama Lengkap</label>
                        <input type="text" name="" required="" class="form-control">
                    </div>

                    <div class="form-group text-left">
                        <label>Email Anda</label>
                        <input type="Email" name="" required="" class="form-control">
                    </div>

                    <div class="form-group text-left">
                        <label>Silahkan Tulis Pesan Anda</label>
                        <textarea rows="5" required="" class="form-control"></textarea>
                    </div>

                    <div class="modal-footer">
                        <button type="submit" data-toggle="modal" data-target="#pesanterkirim" class="btn btn-primary">submit</button>
                        <button type="reset" class="btn btn-danger">reset</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>


<div class="modal fade" id="pesanterkirim" role="dialog" aria-labelledby="pesanterkirim" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Pesan Terkirim</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h6>Saran Anda Telah Berhasil Terkirim</h6>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


<div class="container">
    <h3 class="text-left mt-5 text-white">PRODUK <span class=" font-weight-bold text-info">PP</span><span class="font-weight-bold text-danger">SI</span></h3>

<div class="row">
    <div class="col-md-3 mt-4">
        <div class="card">
            <img src="img/omen.jpg" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Laptop</h5>
                <p class="card-text m-1">Laptop Gaming</p>
                <p style="color: orange" class="m-1">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <i class="far fa-star"></i>
                </p>
                <button type="button" class="btn btn-primary btn-md" disabled>Rp. 30.000.000</button>
                <a href="#" class="btn btn-success">Beli</a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mt-4">
        <div class="card">
            <img src="img/omen.jpg" class="card-img-top" alt="...">
            <div class="card-body ">
                <h5 class="card-title">Laptop</h5>
                <p class="card-text m-1">Laptop Gaming</p>
                <p style="color: orange" class="m-1">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <i class="far fa-star"></i>
                </p>
                <button type="button" class="btn btn-primary btn-md" disabled>Rp. 30.000.000</button>
                <a href="#" class="btn btn-success">Beli</a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mt-4 m">
        <div class="card">
            <img src="img/omen.jpg" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Laptop</h5>
                <p class="card-text m-1">Laptop Gaming</p>
                <p style="color: orange" class="m-1">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <i class="far fa-star"></i>
                </p>
                <button type="button" class="btn btn-primary btn-md" disabled>Rp. 30.000.000</button>
                <a href="#" class="btn btn-success">Beli</a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mt-4">
        <div class="card">
            <img src="img/omen.jpg" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Laptop</h5>
                <p class="card-text m-1">Laptop Gaming</p>
                <p style="color: orange" class="m-1">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <i class="far fa-star"></i>
                </p>
                <button type="button" class="btn btn-primary btn-md" disabled>Rp. 30.000.000</button>
                <a href="#" class="btn btn-success">Beli</a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mt-4">
        <div class="card">
            <img src="img/omen.jpg" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Laptop</h5>
                <p class="card-text m-1">Laptop Gaming</p>
                <p style="color: orange" class="m-1">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <i class="far fa-star"></i>
                </p>
                <button type="button" class="btn btn-primary btn-md" disabled>Rp. 30.000.000</button>
                <a href="#" class="btn btn-success">Beli</a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mt-4">
        <div class="card">
            <img src="img/omen.jpg" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Laptop</h5>
                <p class="card-text m-1">Laptop Gaming</p>
                <p style="color: orange" class="m-1">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <i class="far fa-star"></i>
                </p>
                <button type="button" class="btn btn-primary btn-md" disabled>Rp. 30.000.000</button>
                <a href="#" class="btn btn-success">Beli</a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mt-4">
        <div class="card">
            <img src="img/omen.jpg" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Laptop</h5>
                <p class="card-text m-1">Laptop Gaming</p>
                <p style="color: orange" class="m-1">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <i class="far fa-star"></i>
                </p>
                <button type="button" class="btn btn-primary btn-md" disabled>Rp. 30.000.000</button>
                <a href="#" class="btn btn-success">Beli</a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mt-4">
        <div class="card">
            <img src="img/omen.jpg" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Laptop</h5>
                <p class="card-text m-1">Laptop Gaming</p>
                <p style="color: orange" class="m-1">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                    <i class="far fa-star"></i>
                </p>
                <button type="button" class="btn btn-primary btn-md" disabled>Rp. 30.000.000</button>
                <a href="#" class="btn btn-success">Beli</a>
            </div>
        </div>
    </div>
</div>
</div>

<script src="<?php echo base_url() ?>assets/bootstrap/js/slim.min.js"></script>
<script src="<?php echo base_url() ?>assets/bootstrap/js/popper.min.js"></script>
<script src="<?php echo base_url() ?>assets/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>