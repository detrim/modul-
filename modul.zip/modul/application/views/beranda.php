
<body>
    
<div class="container mt-5 pt-5">
  <div class="row">
    <div class="col-md-4">
        <img class="" src="photo/deni_3x4.jpg" width="300" height="400" alt="">
    </div>
    <div class="col-md-8">
        <h1 class="bg-warning"> <strong> &nbsp DENI TRI MUSLIMIN </strong></h1>
        <h5 class="bg-dark text-white"> <strong> &nbsp &nbsp WEB PROGRAMMER </strong></h5>
      <ul class="list-group list-group-flush mb-1">
            <li class="list-group-item bg-info "> <i class="fas fa-list"></i> <strong>PROFIL</strong> </li>
            <li class="list-group-item">Saya seorang yang ulet, tekun dan memiliki kamuan yang tinggi. Saya seorang ambisius dalam melakukan suatu hal, keahlian saya sebagai web based programming dalam pembuatan maupun pengembangan aplikasi berbasis web menggunakan codeigniter, dengan keahlian lainnya adalah laravel, saya termasuk seorang yang perfeksionis dalam analisa sistem.</li>                
      </ul>
      
      <ul class="list-group list-group-flush">
            <li class="list-group-item bg-info "> <i class="fas fa-list"></i> <strong>PENDIDIKAN</strong> </li>
            <ul class="list-group-flush">
                <li class="list-group-item"> <i class="fa-solid fa-calendar-week"></i> <strong> 2016-2020 </strong></li>
                <li class="list-group-item"> <i class="fa-solid fa-graduation-cap"></i> <strong>S1 - SISTEM INFORMASI</strong> </li>
                <li class="list-group-item"> <i class="fa-solid fa-star"></i> <strong>UNIVERSITAS MERCU BUANA JAKARTA</strong> </li>

            </ul>              
      </ul>
    </div>
  </div>
</div>

<div class="container mt-2">
  <div class="row">
    <div class="col-md-4">
          
    <ul class="list-group list-group-flush mb-1">
        <li class="list-group-item bg-info "> <i class="fas fa-list"></i> <strong>CONTACT</strong> </li>
        <div class="row align-items-start p-3">
            <div class="col-md-1">
              <h6><i class="fa-brands fa-whatsapp"></i></h6>
              <h6><i class="fa-solid fa-envelope"></i></h6>
              <h6><i class="fa-brands fa-linkedin"></i></h6>
            </div>
            <div class="col-md-11">
              <h6>085228109089</h6>
              <h6>denitrimuslimin@gmail.com </h6>
              <h6>https://www.linkedin.com/in/deni-tri-muslimin/ </h6>
            </div>
          </div>          
    </ul>

    <ul class="list-group list-group-flush mb-1">
        <li class="list-group-item bg-info "> <i class="fas fa-list"></i> <strong>SOFTWARE</strong> </li>
        <div class="row align-items-start p-3">
            <div class="col-md-1">
              <h6><i class="fa-solid fa-arrow-right"></i></h6>
              <h6><i class="fa-solid fa-arrow-right"></i></h6>
              <h6><i class="fa-solid fa-arrow-right"></i></h6>
              <h6><i class="fa-solid fa-arrow-right"></i></h6>
            </div>
            <div class="col-md-7">
              <h6> Visual Studio Code</h6>
              <h6> Sublime Text 3 </h6>
              <h6> Git Bash </h6>
              <h6> Postman </h6>
            </div>
            <div class="col-md-4 text-end">
              <h6>80 %</h6>
              <h6>80 %</h6>
              <h6>60 %</h6>
              <h6>55 %</h6>
            </div>
          </div>          
    </ul>

    <ul class="list-group list-group-flush mb-1">
        <li class="list-group-item bg-info "> <i class="fas fa-list"></i> <strong>SOFTSKILL</strong> </li>
        <div class="row align-items-start p-3">
            <div class="col-md-1">
              <h6><i class="fa-solid fa-arrow-right"></i></h6>
              <h6><i class="fa-solid fa-arrow-right"></i></h6>
              <h6><i class="fa-solid fa-arrow-right"></i></h6>
              <h6><i class="fa-solid fa-arrow-right"></i></h6>
            </div>
            <div class="col-md-7">
              <h6> PHP</h6>
              <h6> Codeigniter 3 </h6>
              <h6> Laravel 7</h6>
              <h6> HTML </h6>
            </div>
            <div class="col-md-4 text-end">
              <h6>78 %</h6>
              <h6>80 %</h6>
              <h6>60 %</h6>
              <h6>70 %</h6>
            </div>
          </div>          
    </ul>

    <ul class="list-group list-group-flush mb-1">
        <li class="list-group-item bg-info "> <i class="fas fa-list"></i> <strong>BAHASA</strong> </li>
        <div class="row align-items-start p-3">
            <div class="col-md-1">
              <h6><i class="fa-solid fa-arrow-right"></i></h6>
              <h6><i class="fa-solid fa-arrow-right"></i></h6>
            </div>
            <div class="col-md-7">
              <h6> INDONESIA</h6>
              <h6> INGGRIS </h6>
            </div>
            <div class="col-md-4 text-end text-info">
              <h6>AKTIF</h6>
              <h6>PASSIVE</h6>
            </div>
          </div>          
    </ul>
        <ul class="list-group list-group-flush mb-1">
        <li class="list-group-item bg-info "> <i class="fas fa-list"></i> <strong>HOBI</strong> </li>
        <div class="row align-items-start p-3">
            <div class="col-md-1">
              <h6><i class="fa-solid fa-arrow-right"></i></h6>
              <h6><i class="fa-solid fa-arrow-right"></i></h6>
            </div>
            <div class="col-md-11">
              <h6> GAMING</h6>
              <h6> HIKING </h6>
            </div>
          </div>          
    </ul>

    </div>
    <div class="col-md-8">
    
      <ul class="list-group list-group-flush">
            <li class="list-group-item bg-info "> <i class="fas fa-list"></i> <strong>PRESTASI</strong> </li>
            <ul class="list-group-flush">
                <li class="list-group-item"> <i class="fa-solid fa-calendar-week"></i> <strong> 2019 | DESEMBER </strong></li>
                <li class="list-group-item"> <i class="fa-solid fa-check"></i> <strong>PAMERAN KARYA MAHASISWA ILMU KOMPUTER</strong> </li>
                <li class="list-group-item text-danger"> <i class="fa-solid fa-star"></i> <strong>JUARA 1 </strong> <a target="youtube1" href="https://youtu.be/ReNrPcc_Wsc"><i class="fa-brands fa-youtube"></i></a> </li>
                <li class="list-group-item"> <i class="fa-solid fa-arrow-right"></i> <span> Multiplatform Enterprise dalam era industry 4.0 </span></li>
            </ul>              
      </ul>

      <ul class="list-group list-group-flush">
            <li class="list-group-item bg-info "> <i class="fas fa-list"></i> <strong>MAGANG</strong> </li>
            <ul class="list-group-flush">
                <li class="list-group-item"> <i class="fa-solid fa-calendar-week"></i> <strong> 2020 | FEBRUARI - APRIL </strong></li>
                <li class="list-group-item"> <i class="fa-solid fa-check"></i> <strong>PT. LESTARI MANDIRI ERAJAYA</strong> </li>
                <li class="list-group-item text-danger"> <i class="fa-solid fa-circle"></i> <strong>IT PROGRAMMER</strong> </li>
                <li class="list-group-item"> <i class="fa-solid fa-arrow-right"></i> <span> Migrasi aplikasi monitoring data parkir yang sebelumnya menggunakan visual basic di kembangkan ke website menggunakan framework codeigniter 3. </span></li>
            </ul>              
      </ul>

      <ul class="list-group list-group-flush">
            <li class="list-group-item bg-info "> <i class="fas fa-list"></i> <strong>PENGALAMAN KERJA</strong> </li>
            <ul class="list-group-flush">
                <li class="list-group-item"> <i class="fa-solid fa-calendar-week"></i> <strong> 2021 | NOVEMBER - DESEMBER </strong></li>
                <li class="list-group-item"> <i class="fa-solid fa-check"></i> <strong>PT. CHEETAM GARAM INDONESIA</strong> </li>
                <li class="list-group-item text-danger"> <i class="fa-solid fa-circle"></i> <strong>ADMIN LOGISTIK</strong> </li>
                <li class="list-group-item"> <i class="fa-solid fa-arrow-right"></i> <span> Input data entry dokumen surat jalan, scan dan copy dokumen, check dan hitung invoice surat jalan, hitung laporan bongkaran, membuat surat jalan kembali, check data pengiriman dari sales, mengajukan perpanjangan kontrak kerja sama, monitoring waktu pengiriman dari transporter. </span></li>
            </ul>              
      </ul>

    </div>
  </div>
</div>

</body>

<footer class="bg-dark text-white p-4">
            <center>
            <h5>Deni Tri Muslimin &copy; <?php echo date('Y') ?></h5>
            </center>
</footer>


