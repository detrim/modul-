<body>

    <div class="container mt-5 pt-5">
        <div class="row">
          <h1 class="bg-warning"> APLIKASI MANAGEMENET DATA PARKIR</h1>
          <span class="text-info"> <i class="fa-solid fa-arrow-right"></i> Aplikasi yang berfokus pada report data perusahaan per-periode. </span>
          <hr>
          <div class="col-md-4">
              <ul class="list-group list-group-flush">
                  <li class="list-group-item bg-info "> <i class="fas fa-list"></i> <strong>MANAGEMENT DATA</strong> </li>
                  <li class="list-group-item"> Pengelolaan data perusahaan yang nantinya di olah menjadi sebuah report. </li>      
            </ul>
          </div>
          <div class="col-md-8">
              <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img src="photo/magang/1.png" height="500" class="d-block w-100" alt="...">
                  </div>
                  <div class="carousel-item">
                    <img src="photo/magang/2.png" height="500" class="d-block w-100" alt="...">
                  </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Next</span>
                </button>
              </div>
          </div>

        </div>
      </div>

      <div class="container mt-5">
        <div class="row">
          <h1 class="bg-danger"> APLIKASI MANAGEMENET DATA KONSTRUKSI</h1>
          <span class="text-info"> <i class="fa-solid fa-arrow-right"></i> Aplikasi monitoring data konstruksi yang berfokus pada pengelolaan data kontrak kerja, pembayaran, komplain, data pengguna, data mandor, serta media informasi. </span>
          <hr>
          <div class="col-md-4">
              <ul class="list-group list-group-flush">
                  <li class="list-group-item bg-info "> <i class="fas fa-list"></i> <strong>FRONT END UNTUK MEDIA INFORMASI</strong> </li>
                  <li class="list-group-item"> Menyampaikan informasi mengenai fitur-fitur yang terdapat pada aplikasi</li>
                  <li class="list-group-item"> <i class="fa-solid fa-arrow-right"></i> <span> Aplikasi monitoring data konstruksi yang berfokus pada pengelolaan data kontrak kerja, pembayaran, komplain, data pengguna, data mandor, serta media informasi. </span></li>      
            </ul>
          </div>
          <div class="col-md-8">
              <div class="row featurette">
                  <img src="photo/ta/1.png" height="400" class="d-block w-100" alt="...">
              </div>
          </div>
        </div>

        <div class="row mt-5">
          <div class="col-md-8">
              <div class="row featurette">
                  <img src="photo/ta/4.png" height="400" class="d-block w-100" alt="...">
              </div>
          </div>
          <div class="col-md-4">
              <ul class="list-group list-group-flush">
                  <li class="list-group-item bg-info "> <i class="fas fa-list"></i> <strong>FITUR MANAGEMENT DATA KONTRAK</strong> </li>
                  <li class="list-group-item"> Digunakan untuk mengelola data kontrak kerja yang sedang berjalan, dalam melakukan update data serta memberikan informasi pada pemilik kontrak mengenai progress pekerjaan</li>     
            </ul>
          </div>
        </div>

        <div class="row mt-5 mb-5">
          <div class="col-md-4">
              <ul class="list-group list-group-flush">
                  <li class="list-group-item bg-info "> <i class="fas fa-list"></i> <strong>REPORT PER-PERIODE</strong> </li>
                  <li class="list-group-item"> Pengambilan data perperiode dari aplikasi website.</li>     
            </ul>
          </div>
          <div class="col-md-8">
              <div class="row featurette">
                  <img src="photo/ta/5.png" height="400" class="d-block w-100" alt="...">
              </div>
          </div>
        </div>
      </div>
</body>

<footer class="bg-dark text-white p-4">
            <center>
            <h5>Deni Tri Muslimin &copy; <?php echo date('Y') ?></h5>
            </center>
</footer>
