<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title></title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <!-- <link rel="shortcut icon" href="<?php echo base_url() ?>welcome/img/android-icon-36x36.png"> -->

<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url() ?>assets/bootstrap5/css/bootstrap.min.css">
    <script type="text/javascript" src="<?php echo base_url() ?>assets/bootstrap5/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="<?php echo base_url() ?>assets/bootstrap5/css/style.css">

    <!-- Font Awesome -->
    <link href="<?php echo base_url() ?>assets/fontawesome/css/all.css" rel="stylesheet">
    <script defer src="<?php echo base_url() ?>assets/fontawesome/js/all.js"></script>

    <link href="<?php echo base_url() ?>assets/fontawesome/fontawesome6/css/fontawesome.min.css" rel="stylesheet">
    <script defer src="<?php echo base_url() ?>assets/fontawesome/fontawesome6/js/fontawesome.min.js"></script>

<!-- Datatables -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/datatables/css/dataTables.bootstrap5.min.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/datatables/css/jquery.dataTables.min.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/datatables/css/dataTables.jqueryui.css"/>
 
    <script type="text/javascript" src="<?php echo base_url() ?>assets/datatables/js/dataTables.bootstrap5.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url() ?>assets/datatables/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url() ?>assets/datatables/js/dataTables.jqueryui.min.js"></script>

    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@7.12.15/dist/sweetalert2.min.css'>


</head>