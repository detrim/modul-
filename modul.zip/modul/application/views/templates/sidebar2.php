<body>
<!--     <nav class="navbar navbar-expand-lg navbar-light bg-sendiri fixed-top " id="MainNav">
        <div class="container">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item ml-1 mr-1">
                        <a class="nav-link js-scroll-trigger text-white  " href="<?php echo base_url('beranda') ?>"><strong> PORTOFOLIO </strong> </a>
                    </li>
                    <li class="nav-item ml-1 mr-1 ">
                        <a class="nav-link js-scroll-trigger text-white " href="<?php echo base_url('login') ?>"><strong> DEMO MODUL </strong></a>
                    </li>
                    <li class="nav-item ml-1 mr-1 ">
                        <a class="nav-link js-scroll-trigger text-white " href="<?php echo base_url('project') ?>"><strong> PROJOECT </strong></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav> -->

<nav class="bg-dark fixed-top"> 
  <div class="container">
    <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 ">
      <a href="#" class="nav-link px-2 link-light"><strong>PORTOFOLIO</strong></a>

      <ul class="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
        <li><a href="<?php echo base_url('beranda') ?>" class="nav-link px-3 link-light"><strong> CURRICULUM VITAE </strong> </a></li>
        
        <li><a href="<?php echo base_url('login') ?>" class="nav-link px-3 link-light"><strong> DEMO MODUL </strong></a></li>

        <li><a href="<?php echo base_url('project') ?>" class="nav-link px-3 link-light"><strong> PROJOECT </strong></a></li>

      </ul>

      <div class="col-md-3 text-end spinner-grow text-danger">
        
      </div>
    </div>
  </div>
</nav>


