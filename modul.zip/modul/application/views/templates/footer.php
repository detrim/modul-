<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>


<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script>
window.jQuery || document.write(
    '<script src="<?php echo base_url() ?>assets/src/js/vendor/jquery-3.3.1.min.js"><\/script>')
</script>
<script src="<?php echo base_url() ?>assets/plugins/popper.js/dist/umd/popper.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/perfect-scrollbar/dist/perfect-scrollbar.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/screenfull/dist/screenfull.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js">
</script>
<script src="<?php echo base_url() ?>assets/plugins/jvectormap/jquery-jvectormap.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/jvectormap/tests/assets/jquery-jvectormap-world-mill-en.js">
</script>
<script src="<?php echo base_url() ?>assets/plugins/moment/moment.js"></script>
<script
    src="<?php echo base_url() ?>assets/plugins/tempusdominus-bootstrap-4/build/js/tempusdominus-bootstrap-4.min.js">
</script>
<script src="<?php echo base_url() ?>assets/plugins/d3/dist/d3.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/c3/c3.min.js"></script>
<script src="<?php echo base_url() ?>assets/js/tables.js"></script>
<script src="<?php echo base_url() ?>assets/js/widgets.js"></script>
<script src="<?php echo base_url() ?>assets/js/charts.js"></script>
<script src="<?php echo base_url() ?>assets/dist/js/theme.min.js"></script>
<script src="<?php echo base_url() ?>assets/js/layouts.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/sweetalert/dist/sweetalert.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/summernote/dist/summernote-bs4.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/datedropper/datedropper.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/fullcalendar/dist/fullcalendar.min.js"></script>
<script src="<?php echo base_url() ?>assets/js/calendar.js"></script>

<!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
<script>
(function(b, o, i, l, e, r) {
    b.GoogleAnalyticsObject = l;
    b[l] || (b[l] =
        function() {
            (b[l].q = b[l].q || []).push(arguments)
        });
    b[l].l = +new Date;
    e = o.createElement(i);
    r = o.getElementsByTagName(i)[0];
    e.src = 'https://www.google-analytics.com/analytics.js';
    r.parentNode.insertBefore(e, r)
}(window, document, 'script', 'ga'));
ga('create', 'UA-XXXXX-X', 'auto');
ga('send', 'pageview');
</script>


<script src="<?php echo base_url() ?>assets/plugins/select2/dist/js/select2.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/jquery.repeater/jquery.repeater.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/mohithg-switchery/dist/switchery.min.js"></script>
<script src="<?php echo base_url() ?>assets/js/form-advanced.js"></script>






<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script type="text/javascript"
    src="https://cdn.datatables.net/v/bs4/jszip-2.5.0/dt-1.10.20/b-1.6.1/b-html5-1.6.1/datatables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.20/datatables.js"></script>
<script type="text/javascript" src="//cdn.datatables.net/1.10.17/js/jquery.dataTables.min.js"></script>


<script type="text/javascript">
$(document).ready(function() {
    $('#mytable').DataTable();
});
</script>

<script type="text/javascript">
$(document).ready(function() {
    $('#mytable').DataTable();
});
</script>
<script type="text/javascript">
$(document).ready(function() {
    $('#my_table').DataTable();
});
</script>
<script type="text/javascript">
$(document).ready(function() {
    $('#table_tiga').DataTable();
});
</script>

<!-- <script>
$(document).ready(function() {
    window.setTimeout(function() {
        $(".alert").fadeTo(500, 0).slideUp(500, function() {
            $(this).remove();
        });
    }, 4000);
});
</script> -->


<script>
    $(document).ready(function () {
    $('#example').DataTable();
});
</script>

</body>

</html>