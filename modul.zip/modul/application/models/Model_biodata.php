<?php 

class Model_biodata extends CI_Model{
	public function tambah_biodata($data,$table){
		$this->db->insert($table,$data);
	}
	public function tampil_biodata()
	{
	    $this->db->select('*');
		$this->db->order_by('id','desc');
		$this->db->from('biodata');
		$result = $this->db->get()->result();
		return $result;
	}
	public function detail($id)
	{
		$result = $this->db->where('id', $id)->get('biodata');
		if($result->num_rows() > 0){
			return $result->result();
		}else{
			return false;
		}
	}
	public function hapus($where,$table)
	{
		$this->db->where($where);
		$this->db->delete($table);
	}
}